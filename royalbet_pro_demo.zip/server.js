require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const db = new Database("royalbet.sqlite");
const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || "CHANGE_THIS_DEMO_SECRET_BEFORE_DEPLOYING";

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 credits REAL NOT NULL DEFAULT 1000,
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS bets (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 selections TEXT NOT NULL,
 stake REAL NOT NULL,
 total_odds REAL NOT NULL,
 potential_return REAL NOT NULL,
 status TEXT NOT NULL DEFAULT 'open',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS activity (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER,
 message TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);`);

const count = db.prepare("SELECT COUNT(*) AS n FROM users").get().n;
if (!count) {
  const hash = bcrypt.hashSync("royal123", 10);
  db.prepare("INSERT INTO users(username,password_hash,role,credits) VALUES(?,?,?,?)")
    .run("demo", hash, "user", 1000);
  const adminHash = bcrypt.hashSync("RoyalAdmin26!", 10);
  db.prepare("INSERT INTO users(username,password_hash,role,credits) VALUES(?,?,?,?)")
    .run("admin", adminHash, "admin", 100000);
}
const log = (uid, message) => db.prepare("INSERT INTO activity(user_id,message) VALUES(?,?)").run(uid, message);
const tokenFor = user => jwt.sign({id:user.id, username:user.username, role:user.role}, SECRET, {expiresIn:"12h"});
function auth(req,res,next) {
  try {
    const token = (req.headers.authorization || "").replace(/^Bearer\s+/i,"");
    req.user = jwt.verify(token, SECRET);
    const row = db.prepare("SELECT id,username,role,credits,active FROM users WHERE id=?").get(req.user.id);
    if (!row || !row.active) return res.status(401).json({error:"Llogaria nuk është aktive."});
    req.account = row; next();
  } catch { res.status(401).json({error:"Duhet të hysh përsëri."}); }
}
function admin(req,res,next) {
  if (req.account.role !== "admin") return res.status(403).json({error:"Vetëm administratori."});
  next();
}

app.post("/api/register", async (req,res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(username) || password.length < 8)
    return res.status(400).json({error:"Përdoruesi: 3–20 karaktere; fjalëkalimi: të paktën 8."});
  try {
    const hash = await bcrypt.hash(password, 10);
    const result = db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)").run(username,hash);
    log(result.lastInsertRowid, "U krijua llogari demo.");
    const user = db.prepare("SELECT id,username,role,credits FROM users WHERE id=?").get(result.lastInsertRowid);
    res.json({token:tokenFor(user), user});
  } catch { res.status(409).json({error:"Ky emër përdoruesi ekziston."}); }
});
app.post("/api/login", async (req,res) => {
  const user = db.prepare("SELECT * FROM users WHERE username=?").get(String(req.body.username||"").trim());
  if (!user || !user.active || !(await bcrypt.compare(String(req.body.password||""),user.password_hash)))
    return res.status(401).json({error:"Të dhënat e hyrjes nuk janë të sakta."});
  const safe = {id:user.id,username:user.username,role:user.role,credits:user.credits};
  log(user.id,"Hyrje në llogari.");
  res.json({token:tokenFor(safe),user:safe});
});
app.get("/api/me",auth,(req,res)=>res.json({user:req.account}));
app.get("/api/activity",auth,(req,res)=>{
  const rows = req.account.role==="admin"
    ? db.prepare("SELECT activity.*,users.username FROM activity LEFT JOIN users ON users.id=activity.user_id ORDER BY activity.id DESC LIMIT 100").all()
    : db.prepare("SELECT * FROM activity WHERE user_id=? ORDER BY id DESC LIMIT 50").all(req.user.id);
  res.json(rows);
});
app.get("/api/bets",auth,(req,res)=>res.json(db.prepare("SELECT * FROM bets WHERE user_id=? ORDER BY id DESC LIMIT 50").all(req.user.id)));

app.post("/api/bets",auth,(req,res)=>{
  const stake = Number(req.body.stake);
  const selections = Array.isArray(req.body.selections) ? req.body.selections : [];
  if (!Number.isFinite(stake) || stake <= 0 || stake > 100000 || !selections.length || selections.length > 10)
    return res.status(400).json({error:"Skedina nuk është e vlefshme."});
  const totalOdds = selections.reduce((p,s)=>p*Number(s.odds),1);
  if (selections.some(s=>!Number.isFinite(Number(s.odds)) || Number(s.odds)<1.01 || Number(s.odds)>100))
    return res.status(400).json({error:"Kuotë e pavlefshme."});
  const tx = db.transaction(()=>{
    const current = db.prepare("SELECT credits FROM users WHERE id=?").get(req.user.id).credits;
    if (stake > current) throw new Error("Nuk ke mjaftueshëm kredite virtuale.");
    db.prepare("UPDATE users SET credits=credits-? WHERE id=?").run(stake,req.user.id);
    const ret = stake*totalOdds;
    const id = db.prepare("INSERT INTO bets(user_id,selections,stake,total_odds,potential_return) VALUES(?,?,?,?,?)")
      .run(req.user.id,JSON.stringify(selections),stake,totalOdds,ret).lastInsertRowid;
    log(req.user.id,`U vendos skedinë demo #${id} (${stake} kredite).`);
    return {id,totalOdds,potentialReturn:ret};
  });
  try { res.json(tx()); } catch(e) { res.status(400).json({error:e.message}); }
});

app.get("/api/odds",auth,async(req,res)=>{
  const key = process.env.ODDS_API_KEY;
  const sport = String(req.query.sport || "soccer_epl");
  if (key) {
    try {
      const url = `https://api.the-odds-api.com/v4/sports/${encodeURIComponent(sport)}/odds/?regions=eu&markets=h2h&oddsFormat=decimal&apiKey=${encodeURIComponent(key)}`;
      const response = await fetch(url);
      if (!response.ok) throw new Error("Provider response "+response.status);
      const data = await response.json();
      return res.json({source:"LIVE API",events:data});
    } catch(e) { return res.status(502).json({error:"API sportive nuk u përgjigj. Provo më vonë."}); }
  }
  res.json({source:"DEMO FIXTURES — NOT LIVE",events:[
    {id:"d1",sport_key:"soccer_epl",home_team:"Demo FC",away_team:"Royal United",commence_time:new Date(Date.now()+3600000).toISOString(),bookmakers:[{markets:[{key:"h2h",outcomes:[{name:"Demo FC",price:1.85},{name:"Draw",price:3.4},{name:"Royal United",price:4.1}]}]}]},
    {id:"d2",sport_key:"soccer_epl",home_team:"Golden City",away_team:"Black Stars",commence_time:new Date(Date.now()+7200000).toISOString(),bookmakers:[{markets:[{key:"h2h",outcomes:[{name:"Golden City",price:2.05},{name:"Draw",price:3.2},{name:"Black Stars",price:3.25}]}]}]}
  ]});
});

app.get("/api/admin/users",auth,admin,(req,res)=>res.json(db.prepare("SELECT id,username,role,credits,active,created_at FROM users ORDER BY id DESC").all()));
app.post("/api/admin/credits",auth,admin,(req,res)=>{
  const id=Number(req.body.userId), amount=Number(req.body.amount);
  if(!Number.isInteger(id)||!Number.isFinite(amount)||Math.abs(amount)>1000000) return res.status(400).json({error:"Vlerë e pavlefshme."});
  const u=db.prepare("SELECT id FROM users WHERE id=?").get(id); if(!u) return res.status(404).json({error:"Përdoruesi nuk u gjet."});
  db.prepare("UPDATE users SET credits=MAX(0,credits+?) WHERE id=?").run(amount,id);
  log(id,`Administratori ndryshoi kreditet virtuale (${amount>=0?"+":""}${amount}).`);
  res.json({ok:true});
});
app.post("/api/admin/status",auth,admin,(req,res)=>{
  const id=Number(req.body.userId), active=req.body.active?1:0;
  if(id===req.user.id) return res.status(400).json({error:"Nuk mund të çaktivizosh llogarinë tënde."});
  db.prepare("UPDATE users SET active=? WHERE id=?").run(active,id); res.json({ok:true});
});
app.get("/api/health",(req,res)=>res.json({ok:true,mode:"virtual credits demo"}));
app.listen(PORT,()=>console.log(`ROYALBET PRO running on http://localhost:${PORT}`));
