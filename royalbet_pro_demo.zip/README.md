# ROYALBET PRO — Demo

This is a **virtual-credit demonstration**, not a real-money gambling product.

## Included
- Responsive black/gold frontend.
- Express backend, SQLite database, password hashing and JWT sessions.
- Demo login and admin account.
- User registration, virtual-credit balance, demo bet slip storage.
- Sports odds API integration point (The Odds API).
- Casino game UI simulations (slot, roulette, blackjack, baccarat).
- Admin user listing, virtual-credit adjustments and account activation.

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Set a long random `JWT_SECRET`.
4. Optional: set `ODDS_API_KEY` from The Odds API to request current odds.
5. Run `npm install`, then `npm start`.
6. Open `http://localhost:3000`.

## Demo accounts
- User: `demo` / `royal123`
- Admin: `admin` / `RoyalAdmin26!`

Change these credentials and the JWT secret before any hosted demo. Do not expose an admin account publicly.

## Live odds
Without `ODDS_API_KEY`, the endpoint returns clearly marked sample fixtures. With a valid provider key, `/api/odds?sport=soccer_epl` fetches decimal head-to-head odds from The Odds API. Provider coverage, quotas, pricing and terms vary. Never label demo fixtures as live.

## Important limitations
- Casino buttons are visual random-outcome demonstrations; they do not yet debit/credit the account balance.
- Bet slips are stored as open demo bets. There is no automated settlement/results engine yet.
- No real deposits, withdrawals, payments, cash value or real-money wagering.
- Before any public commercial operation, obtain jurisdiction-specific legal advice, licences/approvals, age/identity controls, responsible-gambling controls, security review and provider permissions.
- This starter is not production-hardened. Add rate limiting, CSRF protections where relevant, secure cookie/session strategy, HTTPS proxy configuration, backups, monitoring and security testing before public exposure.
